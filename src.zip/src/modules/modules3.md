# Exercise 43

- Name: ```modules3```
- Path: ```exercises/modules/modules3.rs```
#### Hint: 

UNIX_EPOCH and SystemTime are declared in the std::time module. Add a use statement
for these two to bring them into scope. You can use nested paths or the glob
operator to bring these two in using only one line.


---



