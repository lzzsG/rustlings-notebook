# Exercise 41

- Name: ```modules1```
- Path: ```exercises/modules/modules1.rs```
#### Hint: 

Everything is private in Rust by default-- but there's a keyword we can use
to make something public! The compiler error should point to the thing that
needs to be public.


---



