# Exercise 45

- Name: ```hashmaps2```
- Path: ```exercises/hashmaps/hashmaps2.rs```
#### Hint: 

Use the `entry()` and `or_insert()` methods of `HashMap` to achieve this.
Learn more at https://doc.rust-lang.org/stable/book/ch08-03-hash-maps.html#only-inserting-a-value-if-the-key-has-no-value



---



