# Exercise 44

- Name: ```hashmaps1```
- Path: ```exercises/hashmaps/hashmaps1.rs```
#### Hint: 

Hint 1: Take a look at the return type of the function to figure out
  the type for the `basket`.
Hint 2: Number of fruits should be at least 5. And you have to put
  at least three different types of fruits.



---



