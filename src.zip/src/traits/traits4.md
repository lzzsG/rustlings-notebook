# Exercise 62

- Name: ```traits4```
- Path: ```exercises/traits/traits4.rs```
#### Hint: 

Instead of using concrete types as parameters you can use traits. Try replacing the
'??' with 'impl <what goes here?>'

See the documentation at: https://doc.rust-lang.org/book/ch10-02-traits.html#traits-as-parameters



---



