# Exercise 60

- Name: ```traits2```
- Path: ```exercises/traits/traits2.rs```
#### Hint: 

Notice how the trait takes ownership of 'self',and returns `Self`.
Try mutating the incoming string vector. Have a look at the tests to see
what the result should look like!

Vectors provide suitable methods for adding an element at the end. See
the documentation at: https://doc.rust-lang.org/std/vec/struct.Vec.html


---



