# Exercise 59

- Name: ```traits1```
- Path: ```exercises/traits/traits1.rs```
#### Hint: 

A discussion about Traits in Rust can be found at:
https://doc.rust-lang.org/book/ch10-02-traits.html



---



