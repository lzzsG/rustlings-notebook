# Exercise 63

- Name: ```traits5```
- Path: ```exercises/traits/traits5.rs```
#### Hint: 

To ensure a parameter implements multiple traits use the '+ syntax'. Try replacing the
'??' with 'impl <> + <>'.

See the documentation at: https://doc.rust-lang.org/book/ch10-02-traits.html#specifying-multiple-trait-bounds-with-the--syntax



---



