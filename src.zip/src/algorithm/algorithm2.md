# Exercise 102

- Name: ```algorithm2```
- Path: ```exercises/algorithm/algorithm2.rs```
#### Hint: 

No hints this time!


---



