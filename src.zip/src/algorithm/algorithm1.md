# Exercise 101

- Name: ```algorithm1```
- Path: ```exercises/algorithm/algorithm1.rs```
#### Hint: 

No hints this time!


---



