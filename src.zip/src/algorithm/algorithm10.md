# Exercise 110

- Name: ```algorithm10```
- Path: ```exercises/algorithm/algorithm10.rs```
#### Hint: 

No hints this time!


---



