# Exercise 105

- Name: ```algorithm5```
- Path: ```exercises/algorithm/algorithm5.rs```
#### Hint: 

No hints this time!


---



