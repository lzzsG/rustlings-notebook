# Exercise 106

- Name: ```algorithm6```
- Path: ```exercises/algorithm/algorithm6.rs```
#### Hint: 

No hints this time!


---



