# Exercise 92

- Name: ```from_into```
- Path: ```exercises/conversions/from_into.rs```
#### Hint: 

Follow the steps provided right before the `From` implementation


---



