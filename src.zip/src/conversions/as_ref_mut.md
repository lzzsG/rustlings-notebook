# Exercise 95

- Name: ```as_ref_mut```
- Path: ```exercises/conversions/as_ref_mut.rs```
#### Hint: 

Add AsRef<str> or AsMut<u32> as a trait bound to the functions.


---



