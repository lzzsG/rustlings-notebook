# Exercise 91

- Name: ```using_as```
- Path: ```exercises/conversions/using_as.rs```
#### Hint: 

Use the `as` operator to cast one of the operands in the last line of the
`average` function into the expected return type.


---



