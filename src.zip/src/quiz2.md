# Exercise 47

- Name: ```quiz2```
- Path: ```exercises/quiz2.rs```
#### Hint: 

No hints this time ;)


---



