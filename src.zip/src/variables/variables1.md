# Exercise 2

- Name: ```variables1```
- Path: ```exercises/variables/variables1.rs```
#### Hint: 

The declaration on line 8 is missing a keyword that is needed in Rust
to create a new variable binding.


---



