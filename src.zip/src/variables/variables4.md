# Exercise 5

- Name: ```variables4```
- Path: ```exercises/variables/variables4.rs```
#### Hint: 

In Rust, variable bindings are immutable by default. But here we're trying
to reassign a different value to x! There's a keyword we can use to make
a variable binding mutable instead.


---



