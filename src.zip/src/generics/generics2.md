# Exercise 58

- Name: ```generics2```
- Path: ```exercises/generics/generics2.rs```
#### Hint: 

Currently we are wrapping only values of type 'u32'.
Maybe we could update the explicit references to this data type somehow?

If you are still stuck https://doc.rust-lang.org/stable/book/ch10-01-syntax.html#in-method-definitions



---



