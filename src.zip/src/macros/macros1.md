# Exercise 84

- Name: ```macros1```
- Path: ```exercises/macros/macros1.rs```
#### Hint: 

When you call a macro, you need to add something special compared to a
regular function call. If you're stuck, take a look at what's inside
`my_macro`.


---



