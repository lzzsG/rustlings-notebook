# Exercise 40

- Name: ```strings4```
- Path: ```exercises/strings/strings4.rs```
#### Hint: 

No hints this time ;)


---



