# Exercise 39

- Name: ```strings3```
- Path: ```exercises/strings/strings3.rs```
#### Hint: 

There's tons of useful standard library functions for strings. Let's try and use some of
them: <https://doc.rust-lang.org/std/string/struct.String.html#method.trim>!

For the compose_me method: You can either use the `format!` macro, or convert the string
slice into an owned string, which you can then freely extend.


---



