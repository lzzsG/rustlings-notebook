# Exercise 27

- Name: ```move_semantics3```
- Path: ```exercises/move_semantics/move_semantics3.rs```
#### Hint: 

The difference between this one and the previous ones is that the first line
of `fn fill_vec` that had `let mut vec = vec;` is no longer there. You can,
instead of adding that line back, add `mut` in one place that will change
an existing binding to be a mutable binding instead of an immutable one :)


---



