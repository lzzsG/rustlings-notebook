# Exercise 25

- Name: ```move_semantics1```
- Path: ```exercises/move_semantics/move_semantics1.rs```
#### Hint: 

So you've got the "cannot borrow immutable local variable `vec1` as mutable" error on line 13,
right? The fix for this is going to be adding one keyword, and the addition is NOT on line 13
where the error is.

Also: Try accessing `vec0` after having called `fill_vec()`. See what happens!


---



