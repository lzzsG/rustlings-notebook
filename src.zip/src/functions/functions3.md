# Exercise 10

- Name: ```functions3```
- Path: ```exercises/functions/functions3.rs```
#### Hint: 

This time, the function *declaration* is okay, but there's something wrong
with the place where we're calling the function.
As a reminder, you can freely play around with different solutions in Rustlings!
Watch mode will only jump to the next exercise if you remove the I AM NOT DONE comment.


---



