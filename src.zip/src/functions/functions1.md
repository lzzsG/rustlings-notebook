# Exercise 8

- Name: ```functions1```
- Path: ```exercises/functions/functions1.rs```
#### Hint: 

This main function is calling a function that it expects to exist, but the
function doesn't exist. It expects this function to have the name `call_me`.
It expects this function to not take any arguments and not return a value.
Sounds a lot like `main`, doesn't it?


---



