# Exercise 11

- Name: ```functions4```
- Path: ```exercises/functions/functions4.rs```
#### Hint: 

The error message points to line 17 and says it expects a type after the
`->`. This is where the function's return type should be -- take a look at
the `is_even` function for an example!

Also: Did you figure out that, technically, u32 would be the more fitting type
for the prices here, since they can't be negative? If so, kudos!


---



