# Exercise 9

- Name: ```functions2```
- Path: ```exercises/functions/functions2.rs```
#### Hint: 

Rust requires that all parts of a function's signature have type annotations,
but `call_me` is missing the type annotation of `num`.


---



