# Exercise 1

- Name: ```intro2```
- Path: ```exercises/intro/intro2.rs```

#### Hint

Add an argument after the format string.

---
