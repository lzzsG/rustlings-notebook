# Exercise 89

- Name: ```clippy2```
- Path: ```exercises/clippy/clippy2.rs```
#### Hint: 

`for` loops over Option values are more clearly expressed as an `if let`


---



