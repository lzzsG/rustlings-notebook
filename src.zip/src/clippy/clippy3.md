# Exercise 90

- Name: ```clippy3```
- Path: ```exercises/clippy/clippy3.rs```
#### Hint: 

No hints this time!


---



