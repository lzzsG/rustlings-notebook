# Exercise 49

- Name: ```options2```
- Path: ```exercises/options/options2.rs```
#### Hint: 

check out:
https://doc.rust-lang.org/rust-by-example/flow_control/if_let.html
https://doc.rust-lang.org/rust-by-example/flow_control/while_let.html

Remember that Options can be stacked in if let and while let.
For example: Some(Some(variable)) = variable2
Also see Option::flatten



---



