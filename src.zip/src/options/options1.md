# Exercise 48

- Name: ```options1```
- Path: ```exercises/options/options1.rs```
#### Hint: 

Options can have a Some value, with an inner value, or a None value, without an inner value.
There's multiple ways to get at the inner value, you can use unwrap, or pattern match. Unwrapping
is the easiest, but how do you do it safely so that it doesn't panic in your face later?


---



