# Exercise 50

- Name: ```options3```
- Path: ```exercises/options/options3.rs```
#### Hint: 

The compiler says a partial move happened in the `match`
statement. How can this be avoided? The compiler shows the correction
needed. After making the correction as suggested by the compiler, do
read: https://doc.rust-lang.org/std/keyword.ref.html


---



