# Exercise 14

- Name: ```if2```
- Path: ```exercises/if/if2.rs```
#### Hint: 

For that first compiler error, it's important in Rust that each conditional
block returns the same type! To get the tests passing, you will need a couple
conditions checking different input values.


---



