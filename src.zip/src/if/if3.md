# Exercise 15

- Name: ```if3```
- Path: ```exercises/if/if3.rs```
#### Hint: 

In Rust, every arm of an `if` expression has to return the same type of value. Make sure the type is consistent across all arms.


---



