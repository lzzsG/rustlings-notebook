# Exercise 17

- Name: ```primitive_types1```
- Path: ```exercises/primitive_types/primitive_types1.rs```
#### Hint: 

No hints this time ;)


---



