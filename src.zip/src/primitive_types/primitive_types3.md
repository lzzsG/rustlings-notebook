# Exercise 19

- Name: ```primitive_types3```
- Path: ```exercises/primitive_types/primitive_types3.rs```
#### Hint: 

There's a shorthand to initialize Arrays with a certain size that does not
require you to type in 100 items (but you certainly can if you want!).
For example, you can do:
let array = ["Are we there yet?"; 10];

Bonus: what are some other things you could have that would return true
for `a.len() >= 100`?


---



