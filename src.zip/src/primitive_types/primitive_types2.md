# Exercise 18

- Name: ```primitive_types2```
- Path: ```exercises/primitive_types/primitive_types2.rs```
#### Hint: 

No hints this time ;)


---



