# Exercise 24

- Name: ```vecs2```
- Path: ```exercises/vecs/vecs2.rs```
#### Hint: 

Hint 1: In the code, the variable `element` represents an item from the Vec as it is being iterated.
Can you try multiplying this?

Hint 2: For the first function, there's a way to directly access the numbers stored
in the Vec, using the * dereference operator. You can both access and write to the
number that way.

After you've completed both functions, decide for yourself which approach you like
better. What do you think is the more commonly used pattern under Rust developers?



---



