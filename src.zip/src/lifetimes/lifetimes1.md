# Exercise 65

- Name: ```lifetimes1```
- Path: ```exercises/lifetimes/lifetimes1.rs```
#### Hint: 

Let the compiler guide you. Also take a look at the book if you need help:
https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html


---



