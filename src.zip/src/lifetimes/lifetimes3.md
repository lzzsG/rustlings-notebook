# Exercise 67

- Name: ```lifetimes3```
- Path: ```exercises/lifetimes/lifetimes3.rs```
#### Hint: 

If you use a lifetime annotation in a struct's fields, where else does it need to be added?


---



