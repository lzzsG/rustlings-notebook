# Exercise 64

- Name: ```quiz3```
- Path: ```exercises/quiz3.rs```
#### Hint: 

To find the best solution to this challenge you're going to need to think back to your
knowledge of traits, specifically Trait Bound Syntax -  you may also need this: `use std::fmt::Display;`.


---



