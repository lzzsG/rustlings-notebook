# Exercise 33

- Name: ```structs3```
- Path: ```exercises/structs/structs3.rs```
#### Hint: 

For is_international: What makes a package international? Seems related to the places it goes through right?

For get_fees: This method takes an additional argument, is there a field in the Package struct that this relates to?

Have a look in The Book, to find out more about method implementations: https://doc.rust-lang.org/book/ch05-03-method-syntax.html


---



