# Exercise 32

- Name: ```structs2```
- Path: ```exercises/structs/structs2.rs```
#### Hint: 

Creating instances of structs is easy, all you need to do is assign some values to its fields.
There are however some shortcuts that can be taken when instantiating structs.
Have a look in The Book, to find out more: https://doc.rust-lang.org/stable/book/ch05-01-defining-structs.html#creating-instances-from-other-instances-with-struct-update-syntax


---



