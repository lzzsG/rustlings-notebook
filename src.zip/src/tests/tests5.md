# Exercise 96

- Name: ```tests5```
- Path: ```exercises/tests/tests5.rs```
#### Hint: 

For more information about `unsafe` and soundness, see
https://doc.rust-lang.org/nomicon/safe-unsafe-meaning.html


---



