# Exercise 69

- Name: ```tests2```
- Path: ```exercises/tests/tests2.rs```
#### Hint: 

Like the previous exercise, you don't need to write any code to get this test to compile and
run. `assert_eq!` is a macro that takes two arguments and compares them. Try giving it two
values that are equal! Try giving it two arguments that are different! Try giving it two values
that are of different types! Try switching which argument comes first and which comes second!


---



