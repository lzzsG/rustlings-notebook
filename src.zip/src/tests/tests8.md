# Exercise 99

- Name: ```tests8```
- Path: ```exercises/tests/tests8.rs```
#### Hint: 

The command to set up an environment variable is "rustc-cfg=CFG[="VALUE"]", while
the square brackets means optional. Be sure what `CFG` and `VALUE` you want here.


---



