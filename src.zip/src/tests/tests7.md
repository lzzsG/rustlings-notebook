# Exercise 98

- Name: ```tests7```
- Path: ```exercises/tests/tests7.rs```
#### Hint: 

The command to set up an environment variable is "rustc-env=VAR=VALUE".


---



