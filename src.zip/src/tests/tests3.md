# Exercise 70

- Name: ```tests3```
- Path: ```exercises/tests/tests3.rs```
#### Hint: 

You can call a function right where you're passing arguments to `assert!` -- so you could do
something like `assert!(having_fun())`. If you want to check that you indeed get false, you
can negate the result of what you're doing using `!`, like `assert!(!having_fun())`.


---



