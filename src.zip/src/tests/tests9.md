# Exercise 100

- Name: ```tests9```
- Path: ```exercises/tests/tests9.rs```
#### Hint: 

No hints this time!


---



