# Exercise 97

- Name: ```tests6```
- Path: ```exercises/tests/tests6.rs```
#### Hint: 

The function to transform a box to a raw pointer is called `Box::into_raw`, while
the function to reconstruct a box from a raw pointer is called `Box::from_raw`.
Search the official API documentation for more information:
https://doc.rust-lang.org/nightly/std/index.html


---



