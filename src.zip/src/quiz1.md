# Exercise 16

- Name: ```quiz1```
- Path: ```exercises/quiz1.rs```
#### Hint: 

No hints this time ;)


---



