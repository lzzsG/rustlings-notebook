# Exercise 75

- Name: ```iterators4```
- Path: ```exercises/iterators/iterators4.rs```
#### Hint: 

In an imperative language, you might write a for loop that updates
a mutable variable. Or, you might write code utilizing recursion
and a match clause. In Rust you can take another functional
approach, computing the factorial elegantly with ranges and iterators.

Hint 2: Check out the `fold` and `rfold` methods!


---



