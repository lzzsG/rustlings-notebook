# Exercise 53

- Name: ```errors3```
- Path: ```exercises/error_handling/errors3.rs```
#### Hint: 

If other functions can return a `Result`, why shouldn't `main`? It's a fairly common
convention to return something like Result<(), ErrorType> from your main function.
The unit (`()`) type is there because nothing is really needed in terms of positive
results.


---



