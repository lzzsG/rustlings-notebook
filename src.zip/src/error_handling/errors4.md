# Exercise 54

- Name: ```errors4```
- Path: ```exercises/error_handling/errors4.rs```
#### Hint: 

`PositiveNonzeroInteger::new` is always creating a new instance and returning an `Ok` result.
It should be doing some checking, returning an `Err` result if those checks fail, and only
returning an `Ok` result if those checks determine that everything is... okay :)


---



