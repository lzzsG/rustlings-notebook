# Exercise 34

- Name: ```enums1```
- Path: ```exercises/enums/enums1.rs```
#### Hint: 

No hints this time ;)


---



