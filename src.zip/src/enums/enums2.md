# Exercise 35

- Name: ```enums2```
- Path: ```exercises/enums/enums2.rs```
#### Hint: 

You can create enumerations that have different variants with different types
such as no data, anonymous structs, a single string, tuples, ...etc


---



