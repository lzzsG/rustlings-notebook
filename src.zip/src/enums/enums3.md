# Exercise 36

- Name: ```enums3```
- Path: ```exercises/enums/enums3.rs```
#### Hint: 

As a first step, you can define enums to compile this code without errors.
and then create a match expression in `process()`.
Note that you need to deconstruct some message variants
in the match expression to get value in the variant.


---



